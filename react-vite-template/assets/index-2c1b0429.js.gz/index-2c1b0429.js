import{j as e}from"./index-1df45824.js";function r(){return e.jsx(e.Fragment,{children:"detail"})}export{r as default};
