import{j as r}from"./index-90e5c117.js";function e(){return r.jsx(r.Fragment,{children:"record"})}export{e as default};
