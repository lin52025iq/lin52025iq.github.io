import{j as r}from"./index-1df45824.js";function e(){return r.jsx(r.Fragment,{children:"record"})}export{e as default};
