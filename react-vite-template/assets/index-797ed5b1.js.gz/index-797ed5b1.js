import{j as r}from"./index-9e6d5646.js";function e(){return r.jsx(r.Fragment,{children:"record"})}export{e as default};
