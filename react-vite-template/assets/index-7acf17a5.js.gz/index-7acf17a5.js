import{j as r}from"./index-340efc4c.js";function e(){return r.jsx(r.Fragment,{children:"record"})}export{e as default};
