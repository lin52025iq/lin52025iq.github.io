import{j as e}from"./index-9e6d5646.js";function r(){return e.jsx(e.Fragment,{children:"detail"})}export{r as default};
