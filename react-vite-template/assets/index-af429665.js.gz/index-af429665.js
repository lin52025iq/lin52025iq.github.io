import{j as e}from"./index-340efc4c.js";function r(){return e.jsx(e.Fragment,{children:"detail"})}export{r as default};
