import{j as e}from"./index-90e5c117.js";function r(){return e.jsx(e.Fragment,{children:"detail"})}export{r as default};
